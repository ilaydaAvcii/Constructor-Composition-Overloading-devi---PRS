﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ödev
{
    class Kasa
    {
        public string KasaTipi { get; set; }

        public Kasa(string kasaTipi)
        {
            KasaTipi = kasaTipi;
        }
    }
}

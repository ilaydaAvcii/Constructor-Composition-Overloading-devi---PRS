﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ödev
{
    class Pencere
    {
        public int PencereSayısı { get; set; }

        public Pencere(int pencereSayısı)
        {
            PencereSayısı = pencereSayısı;
        }
    }
}

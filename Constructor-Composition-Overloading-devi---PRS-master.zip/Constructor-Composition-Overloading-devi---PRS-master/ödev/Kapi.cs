﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ödev
{
    class Kapi
    {
    public int KapıSayısı { get; set; }

        public Kapi(int kapıSayısı)
        {
            KapıSayısı = kapıSayısı;
        }
    }

}


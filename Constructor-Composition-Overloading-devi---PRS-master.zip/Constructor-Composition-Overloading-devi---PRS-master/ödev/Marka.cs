﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ödev
{
    class Marka
    {
        public string MarkaAdı { get; set; }

        public Marka(string markaAdı)
        {
            MarkaAdı = markaAdı;
        }
    }
}
